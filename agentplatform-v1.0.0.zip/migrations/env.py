import asyncio
from logging.config import fileConfig

from alembic import context
from sqlalchemy import pool
from sqlalchemy.engine import Connection
from sqlalchemy.ext.asyncio import async_engine_from_config

# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

# Interpret the config file for Python logging.
# This line sets up loggers basically.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# 平台 ORM 元数据(alembic autogenerate 据此生成迁移;见 004 数据模型)
# 导入业务模型以注册进 Base.metadata(M2 起;后续里程碑在此补充)
from agentplatform.config import settings
from agentplatform.core.auth.model import User  # noqa: F401
from agentplatform.core.db.base import Base
from agentplatform.core.interact.model import InteractEvent  # noqa: F401
from agentplatform.core.kb.model import KbChunk, KbDocument, KnowledgeBase  # noqa: F401
from agentplatform.core.llm.model import LlmEndpoint  # noqa: F401
from agentplatform.core.message.model import Message  # noqa: F401
from agentplatform.core.plugin.model import Plugin  # noqa: F401
from agentplatform.core.registry.model import SkillTool  # noqa: F401
from agentplatform.core.session.model import Session  # noqa: F401

target_metadata = Base.metadata

# URL 从应用配置读取,不写死在 alembic.ini(避免环境差异)
config.set_main_option("sqlalchemy.url", settings.database_url)

# other values from the config, defined by the needs of env.py,
# can be acquired:
# my_important_option = config.get_main_option("my_important_option")
# ... etc.


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode.

    This configures the context with just a URL
    and not an Engine, though an Engine is acceptable
    here as well.  By skipping the Engine creation
    we don't even need a DBAPI to be available.

    Calls to context.execute() here emit the given string to the
    script output.

    """
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection: Connection) -> None:
    context.configure(connection=connection, target_metadata=target_metadata)

    with context.begin_transaction():
        context.run_migrations()


async def run_async_migrations() -> None:
    """In this scenario we need to create an Engine
    and associate a connection with the context.

    """

    connectable = async_engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations)

    await connectable.dispose()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode."""

    asyncio.run(run_async_migrations())


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
