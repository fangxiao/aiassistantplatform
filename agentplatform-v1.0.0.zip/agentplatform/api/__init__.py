"""API 路由聚合。

基础路径 /api(见 005 §1);错误统一为 {error: {code, message}}。
认证/对话/插件/注册表/LLM 端点子路由由对应里程碑挂载。
"""

from fastapi import APIRouter

from agentplatform.api import (
    admin_llm,
    assistants,
    auth,
    browser,
    chat,
    dev_session,
    diagnostics,
    files,
    insights,
    health,
    kb,
    llm_user,
    mcp,
    memory,
    notify,
    plugins,
    registry,
    scheduler,
    specs,
    workbench,
)

api_router = APIRouter()
api_router.include_router(health.router)
api_router.include_router(auth.router)
api_router.include_router(assistants.router)
api_router.include_router(registry.router)
api_router.include_router(admin_llm.router)
api_router.include_router(plugins.router)
api_router.include_router(chat.router)
api_router.include_router(specs.router)
api_router.include_router(browser.router)
api_router.include_router(dev_session.router)
api_router.include_router(files.router)
api_router.include_router(kb.router)
api_router.include_router(memory.router)
api_router.include_router(mcp.router)
api_router.include_router(insights.router)
api_router.include_router(notify.router)
api_router.include_router(diagnostics.router)
api_router.include_router(llm_user.router)
api_router.include_router(workbench.router)
api_router.include_router(scheduler.router)


